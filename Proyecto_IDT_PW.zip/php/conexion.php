<?php
//conectamos con mysql
$mysqli = new mysqli("localhost","root","","proyecto_idt");
//localhost: ip de la maquina donde esta la bd
//root: usuario de mysql
//": (tercer valor)el password del usuario root
//bd_idt: nombre de la bd a la que nos queremos conectar